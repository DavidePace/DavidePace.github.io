package game;

import it.unical.mat.embasp.languages.Id;
import it.unical.mat.embasp.languages.Param;

@Id("student")
public class Student
{
	@Param(0)
	private int id;
	@Param(1)
	private int row;
	@Param(2)
	private int column;

	public Student()
	{
		id = row = column = 0;
	}

	public Student(final int id, final int row, final int column)
	{
		this.id = id;
		this.row = row;
		this.column = column;
	}

	public int getColumn()
	{
		return column;
	}

	public int getId()
	{
		return id;
	}

	public int getRow()
	{
		return row;
	}

	public void setColumn(int column)
	{
		this.column = column;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public void setRow(int row)
	{
		this.row = row;
	}

	@Override
	public String toString()
	{
		return "Student{" + "id=" + id + ", row=" + row + ", column=" + column + '}';
	}
}
