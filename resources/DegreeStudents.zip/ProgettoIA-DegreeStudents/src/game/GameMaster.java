package game;

import java.util.Scanner;

import it.unical.mat.embasp.base.Handler;
import it.unical.mat.embasp.base.InputProgram;
import it.unical.mat.embasp.base.OptionDescriptor;
import it.unical.mat.embasp.base.Output;
import it.unical.mat.embasp.languages.asp.ASPInputProgram;
import it.unical.mat.embasp.languages.asp.AnswerSet;
import it.unical.mat.embasp.languages.asp.AnswerSets;
import it.unical.mat.embasp.platforms.desktop.DesktopHandler;
import it.unical.mat.embasp.specializations.dlv.DLVFilterOption;
import it.unical.mat.embasp.specializations.dlv.desktop.DLVDesktopService;

public class GameMaster
{
	private static int N = 8;
	private final static int[][] chessboard =
	{
			{ 0, 1, 0, 2, 0, 3, 0, 4 },
			{ 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0 } };
	private static Handler handler;
	// private static int studentTurn;
	private static boolean degreeTurn;
	private static Degree degree;
	private static Scanner scan;
	private static InputProgram program;
	private static OptionDescriptor filter;

	private static boolean checkLose()
	{
		final int degreeRow = degree.getRow() - 1;
		final int degreeCol = degree.getColumn() - 1;
		if (degreeRow == N - 1)
		{
			if (degreeCol == 0)
			{
				if (chessboard[degreeRow - 1][degreeCol + 1] != 0)
					return true;
			}
			else if (chessboard[degreeRow - 1][degreeCol - 1] != 0 && chessboard[degreeRow - 1][degreeCol + 1] != 0)
				return true;
		}
		else if (degreeRow == 0)
		{
			if (degreeCol == N - 1)
			{
				if (chessboard[degreeRow + 1][degreeCol - 1] != 0)
					return true;
			}
			else if (chessboard[degreeRow + 1][degreeCol - 1] != 0 && chessboard[degreeRow + 1][degreeCol + 1] != 0)
				return true;
		}
		else if (degreeCol == N - 1)
		{
			if (degreeRow == 0)
			{
				if (chessboard[degreeRow + 1][degreeCol - 1] != 0)
					return true;
			}
			else if (chessboard[degreeRow - 1][degreeCol - 1] != 0 && chessboard[degreeRow + 1][degreeCol - 1] != 0)
				return true;
		}
		else if (degreeCol == 0)
		{
			if (degreeRow == N - 1)
			{
				if (chessboard[degreeRow - 1][degreeCol + 1] != 0)
					return true;
			}
			else if (chessboard[degreeRow - 1][degreeCol + 1] != 0 && chessboard[degreeRow + 1][degreeCol + 1] != 0)
				return true;
		}
		else if (chessboard[degreeRow - 1][degreeCol - 1] != 0 && chessboard[degreeRow - 1][degreeCol + 1] != 0
				&& chessboard[degreeRow + 1][degreeCol + 1] != 0 && chessboard[degreeRow + 1][degreeCol - 1] != 0)
			return true;
		return false;
	}

	private static boolean degreeMove()
	{
		System.out.println("Degree: " + degree.getRow() + " : " + degree.getColumn());
		scan = new Scanner(System.in);
		boolean moved = false;
		do
		{
			System.err.println("CHOOSE A DIRECTION:");
			final String choose = scan.next();
			switch (choose)
			{
			case "e":
				if ((degree.getRow() - 2) >= 0 && (degree.getColumn()) < N
						&& chessboard[degree.getRow() - 2][degree.getColumn()] == 0)
				{
					chessboard[degree.getRow() - 1][degree.getColumn() - 1] = 0;
					chessboard[degree.getRow() - 2][degree.getColumn()] = 5;
					degree.setRow(degree.getRow() - 1);
					degree.setColumn(degree.getColumn() + 1);
					moved = true;
				}
				break;
			case "q":
				if ((degree.getRow() - 2) >= 0 && (degree.getColumn() - 2) >= 0
						&& chessboard[degree.getRow() - 2][degree.getColumn() - 2] == 0)
				{
					chessboard[degree.getRow() - 1][degree.getColumn() - 1] = 0;
					chessboard[degree.getRow() - 2][degree.getColumn() - 2] = 5;
					degree.setRow(degree.getRow() - 1);
					degree.setColumn(degree.getColumn() - 1);
					moved = true;
				}
				break;
			case "c":
				if ((degree.getRow()) < N && (degree.getColumn()) < N
						&& chessboard[degree.getRow()][degree.getColumn()] == 0)
				{
					chessboard[degree.getRow() - 1][degree.getColumn() - 1] = 0;
					chessboard[degree.getRow()][degree.getColumn()] = 5;
					degree.setRow(degree.getRow() + 1);
					degree.setColumn(degree.getColumn() + 1);
					moved = true;
				}
				break;
			case "z":
				if ((degree.getRow()) < N && (degree.getColumn() - 2) >= 0
						&& chessboard[degree.getRow()][degree.getColumn() - 2] == 0)
				{
					chessboard[degree.getRow() - 1][degree.getColumn() - 1] = 0;
					chessboard[degree.getRow()][degree.getColumn() - 2] = 5;
					degree.setRow(degree.getRow() + 1);
					degree.setColumn(degree.getColumn() - 1);
					moved = true;
				}
				break;
			default:
				break;
			}
		}
		while (!moved);
		if (degree.getRow() - 1 == 0)
			return true;
		for (int i = 0; i < degree.getRow(); i++)
		{
			for (int j = 0; j < N; j++)
			{
				if (chessboard[i][j] >= 1 && chessboard[i][j] <= 4)
					return false;
			}
		}
		return true;
	}

	private static boolean degreeMoveCPU()
	{
		filter.clear();
		filter.addOption("-filter=degree,upRight,upLeft,downRight,downLeft ");
		final Output out = handler.startSync();
		if (!(out instanceof AnswerSets))
			return false;
		final AnswerSets answerSets = (AnswerSets) out;
		if (answerSets.getAnswersets().size() == 0)
		{
			System.out.println("NESSUNA MOSSA POSSIBILE");
			return false;
		}
		final AnswerSet as = answerSets.getAnswersets().get(0);
		try
		{
			System.out.println("Answer Set DEGREE:");
			System.out.println(as.getAnswerSet());
			String direction = null;

			if (as.getAnswerSet().toString().contains("upRight"))
				direction = "upRight";
			else if (as.getAnswerSet().toString().contains("upLeft"))
				direction = "upLeft";
			else if (as.getAnswerSet().toString().contains("downRight"))
				direction = "downRight";
			else if (as.getAnswerSet().toString().contains("downLeft"))
				direction = "downLeft";

			Degree curDegree = null;

			for (final Object obj : as.getAtoms())
			{
				// System.out.println(obj);
				curDegree = (Degree) obj;
				System.out.println("Degree moves " + direction);
			}
			if (curDegree != null)
			{
				int degreeRow = curDegree.getRow() - 1;
				int degreeCol = curDegree.getColumn() - 1;
				chessboard[degreeRow][degreeCol] = 0;
				if (direction != null)
					switch (direction)
					{
					case "upRight":
						degreeRow--;
						degreeCol++;
						// chessboard[degreeRow - 1][degreeCol + 1] = 5;
						break;
					case "upLeft":
						degreeRow--;
						degreeCol--;
						// chessboard[degreeRow - 1][degreeCol - 1] = 5;
						break;
					case "downRight":
						degreeRow++;
						degreeCol++;
						// chessboard[degreeRow + 1][degreeCol + 1] = 5;
						break;
					case "downLeft":
						degreeRow++;
						degreeCol--;
						// chessboard[degreeRow + 1][degreeCol - 1] = 5;
						break;
					default:
						break;
					}
				chessboard[degreeRow][degreeCol] = 5;
				degree.setRow(degreeRow + 1);
				degree.setColumn(degreeCol + 1);
			}
		}
		catch (final Exception e)
		{
			e.printStackTrace();
		}

		if (degree.getRow() - 1 == 0)
			return true;
		for (int i = 0; i < degree.getRow(); i++)
		{
			for (int j = 0; j < N; j++)
			{
				if (chessboard[i][j] >= 1 && chessboard[i][j] <= 4)
					return false;
			}
		}
		return true;
	}

	public static void main(String[] args)
	{
		// handler = new DesktopHandler(new DLVDesktopService(
		// "C:\\Users\\Alessandro\\workspaceJNeon\\ProgettoIA-DegreeStudents\\resources\\dlv.exe"));
		handler = new DesktopHandler(
				new DLVDesktopService(Thread.currentThread().getContextClassLoader().getResource("dlv.exe").getPath()));
		program = new ASPInputProgram();
		handler.addProgram(program);
		filter = new DLVFilterOption("");
		// System.out.println(filter.getOptions());
		handler.addOption(filter);

		// studentTurn = 1;
		degreeTurn = true;

		final Scanner scan = new Scanner(System.in);
		int choice = 0;
		do
		{
			System.out.println("CHOOSE THE STARTING COLUMN (1-3-5-7)");
			choice = scan.nextInt();
		}
		while (choice < 1 || choice > 8 || choice % 2 == 0);
		degree = new Degree(8, choice);
		chessboard[7][choice - 1] = 5;

		boolean cpuControlled = false;
		do
		{
			System.out.println("CPU OR PLAYER?");
			System.out.println("1. Player");
			System.out.println("2. CPU");
			choice = scan.nextInt();
		}
		while (choice < 1 || choice > 2);
		if (choice == 2)
			cpuControlled = true;

		// for (int i = 0; i < N; i++)
		// {
		// for (int j = 0; j < N; j++)
		// {
		// if (chessboard[i][j] == 5)
		// {
		// degree = new Degree(i + 1, j + 1);
		// break;
		// }
		// }
		// }

		showChessboard();
		while (true)
		{
			program.clearAll();
			// program.addFilesPath(
			// "C:\\Users\\Alessandro\\workspaceJNeon\\ProgettoIA-DegreeStudents\\resources\\newProgetto.txt");
			if (degreeTurn)
				program.addFilesPath(System.getProperty("user.dir") + "/resources/DegreeAI.txt");
			else
				program.addFilesPath(System.getProperty("user.dir") + "/resources/newProgetto.txt");

			try
			{
				for (int i = 0; i < N; i++)
					for (int j = 0; j < N; j++)
						if (chessboard[i][j] > 0 && chessboard[i][j] < 5)
							program.addObjectInput(new Student(chessboard[i][j], i + 1, j + 1));
				// else if (chessboard[i][j] == 5)
				// program.addObjectInput(new Degree(i + 1, j + 1));
				program.addObjectInput(degree);
				// program.addObjectInput(new Turn(studentTurn));
			}
			catch (final Exception e)
			{
				e.printStackTrace();
			}
			// System.out.println();
			// System.err.println("FACTS:");
			// System.out.println(program.getPrograms());
			// System.out.println();
			if (degreeTurn)
			{
				if (cpuControlled)
				{
					if (degreeMoveCPU())
					{
						System.out.println("================= HAI VINTO! =================");
						showChessboard();
						return;
					}
					showChessboard();
				}
				else if (degreeMove())
				{
					System.out.println("================= HAI VINTO! =================");
					showChessboard();
					return;
				}
			}
			else
			{
				studentMove();
				// studentTurn++;
				// if (studentTurn >= 5)
				// studentTurn = 1;
				if (checkLose())
				{
					System.out.println("================= HAI PERSO! =================");
					showChessboard();
					return;
				}
				showChessboard();
			}

			degreeTurn = !degreeTurn;
			// try
			// {
			// System.in.read();
			// }
			// catch (final IOException e)
			// {
			// e.printStackTrace();
			// }
			System.out.println("================= Turno terminato =================");
			if (cpuControlled)
				try
				{
					Thread.sleep(500);
				}
				catch (final InterruptedException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}

	private static void showChessboard()
	{
		for (int i = 0; i < N; i++)
		{
			for (int j = 0; j < N; j++)
			{
				if ((i + j) % 2 == 0)
					System.out.print("- ");
				else if (chessboard[i][j] == 0)
					System.out.print("o ");
				else
					System.out.print(chessboard[i][j] + " ");
			}
			System.out.println();
		}
	}

	private static void studentMove()
	{
		filter.clear();
		filter.addOption("-filter=student,left,right ");
		final Output out = handler.startSync();

		if (!(out instanceof AnswerSets))
			return;
		final AnswerSets answerSets = (AnswerSets) out;
		if (answerSets.getAnswersets().size() == 0)
		{
			System.out.println("AS VUOTO");
			return;
		}
		final AnswerSet as = answerSets.getAnswersets().get(0);
		try
		{
			System.out.println("Answer Set:");
			System.out.println(as.getAnswerSet());
			Student curStudent = null;
			String direction = null;
			int id = 0;

			if (as.getAnswerSet().toString().contains("right"))
			{
				final int idLocation = as.getAnswerSet().toString().lastIndexOf('(') + 1;
				direction = "right";
				// System.out.println(as.getAnswerSet().toString().substring(71, 72));
				id = Integer.parseInt(as.getAnswerSet().toString().substring(idLocation, idLocation + 1));
			}
			else if (as.getAnswerSet().toString().contains("left"))
			{
				direction = "left";
				final int idLocation = as.getAnswerSet().toString().lastIndexOf('(') + 1;
				// System.out.println(as.getAnswerSet().toString().substring(70, 71));
				id = Integer.parseInt(as.getAnswerSet().toString().substring(idLocation, idLocation + 1));
			}
			for (final Object obj : as.getAtoms())
			{
				// System.out.println(obj);
				if (obj.toString().contains("id=" + id))
				{
					curStudent = (Student) obj;
					System.out.println("Student " + curStudent.getId() + " moves " + direction);
				}
			}
			if (curStudent != null)
			{
				chessboard[curStudent.getRow() - 1][curStudent.getColumn() - 1] = 0;
				if (direction != null && direction.equals("right"))
					chessboard[curStudent.getRow()][curStudent.getColumn()] = curStudent.getId();
				else if (direction != null && direction.equals("left"))
					chessboard[curStudent.getRow()][curStudent.getColumn() - 2] = curStudent.getId();
			}
		}
		catch (final Exception e)
		{
			e.printStackTrace();
		}
	}

}
