package game;

import it.unical.mat.embasp.languages.Id;
import it.unical.mat.embasp.languages.Param;

@Id("degree")
public class Degree
{
	@Param(0)
	private int row;
	@Param(1)
	private int column;

	public Degree()
	{
		row = column = 0;
	}

	public Degree(final int row, final int column)
	{
		this.row = row;
		this.column = column;
	}

	public int getColumn()
	{
		return column;
	}

	public int getRow()
	{
		return row;
	}

	public void setColumn(int column)
	{
		this.column = column;
	}

	public void setRow(int row)
	{
		this.row = row;
	}

	@Override
	public String toString()
	{
		return "Degree{" + "row=" + row + ", column=" + column + '}';
	}
}
