package game;

import it.unical.mat.embasp.languages.Id;
import it.unical.mat.embasp.languages.Param;

@Id("turn")
public class Turn
{
	@Param(0)
	private int id;

	public Turn()
	{
		id = 0;
	}

	public Turn(int id)
	{
		this.id = id;
	}

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}
}
